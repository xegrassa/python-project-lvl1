from brain_games import cli


def main():
    cli.welcome()
    cli.run()


if __name__ == '__main__':
    main()
